"""The only external entry point required to complete the assignment."""
from src.interface import ApplicationInterface

if __name__=='__main__':
    raise SystemExit(ApplicationInterface().run())
