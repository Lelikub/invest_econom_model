from dataclasses import fields
from pathlib import Path
import csv
import math
from .models import ProjectInputData, MarketAssumptions, ShockParameters


class DataRepository:
    @staticmethod
    def load(data_dir: Path) -> tuple[ProjectInputData,MarketAssumptions,ShockParameters]:
        records=[]
        for group,model in [('project',ProjectInputData),('market',MarketAssumptions),('shock',ShockParameters)]:
            with (data_dir/f'{group}_parameters.csv').open(encoding='utf-8-sig',newline='') as stream:
                rows=list(csv.DictReader(stream))
            values={}
            for row in rows:
                key=row['parameter_code']
                if key in values or row['parsing_status']!='PASS' or not row['source_file']:
                    raise ValueError(f'Invalid parameter provenance/duplicate: {key}')
                if key in ('peer','index'):
                    values[key]=row['raw_value']
                else:
                    values[key]=float(row['numeric_value'])
                    if not math.isfinite(values[key]):
                        raise ValueError(f'Non-finite parameter: {key}')
            allowed={f.name for f in fields(model)}
            if set(values)-allowed:
                raise ValueError(f'Unexpected keys: {set(values)-allowed}')
            records.append(model(**values))
        return tuple(records)
