from ..models import CalculationResult
from ..calculators.finance import (EffectiveTaxCalculator,LeverageCalculator,
    HamadaBetaCalculator,CAPMCalculator,CostOfDebtCalculator,WACCCalculator)


class MetricService:
    def base(self,p,m):
        tax=EffectiveTaxCalculator.calculate(p.t_nominal,p.rd_relief,p.t_floor)
        de_peer=LeverageCalculator.calculate(m.debt_peer,m.equity_peer)
        bu=HamadaBetaCalculator.unlever(m.beta_peer,m.tax_peer,de_peer)
        de=LeverageCalculator.calculate(p.wd,p.we)
        bl=HamadaBetaCalculator.relever(bu,tax,de)
        ke=CAPMCalculator.calculate(m.rf,bl,m.erp,m.crp)
        kd=CostOfDebtCalculator.calculate(m.rf,p.s_base)
        net=CostOfDebtCalculator.after_tax(kd,tax)
        return CalculationResult('base',dict(t_eff=tax,de_peer=de_peer,beta_u=bu,de=de,beta_l=bl,
            rf=m.rf,erp=m.erp,crp=m.crp,we=p.we,wd=p.wd,ke=ke,kd=kd,kd_after_tax=net,
            wacc=WACCCalculator.calculate(p.we,p.wd,ke,net),dscr=p.dscr0,
            equity=p.capex*p.we,debt=p.capex*p.wd,ebitda=p.ebitda,credit_spread=0.,delta_total=0.,pi_exp=0.,beta_multiplier=1.))

    @staticmethod
    def decomposition(base,stress):
        b=base.metrics; s=stress.metrics
        return [dict(component='Стоимость собственного капитала',delta=b['we']*(s['ke']-b['ke'])),
            dict(component='Стоимость долга после налога',delta=b['wd']*(s['kd_after_tax']-b['kd_after_tax'])),
            dict(component='Изменение весов (при стрессовых ставках)',delta=(s['we']-b['we'])*s['ke']+(s['wd']-b['wd'])*s['kd_after_tax'])]
